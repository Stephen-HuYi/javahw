package helloworld;

public class Test {
	public static void main(String[] args) {
		HelloWorld helloWorld = new HelloWorld();
		helloWorld.say();
		System.out.println("You should say: Hello World");
	}
}
