package example;

public class Example {
	public int show(int x) {
		System.out.println("Hello" + x);
		return x + 1;
	}
}
